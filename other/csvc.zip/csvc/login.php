<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đăng nhập hệ thống</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #eef2f3;
        height: 100vh;
        margin: 0;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .login-box {
        background: #fff;
        width: 360px;
        padding: 35px 40px;
        border-radius: 14px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.12);
        text-align: center;
    }

    h2 {
        margin-bottom: 25px;
        font-size: 22px;
        font-weight: 700;
        color: #222;
    }

    label {
        font-size: 15px;
        font-weight: 600;
        display: block;
        text-align: left;
        margin-bottom: 6px;
        color: #444;
    }

    input[type="text"],
    input[type="password"] {
            width: 93%;
        padding: 11px 12px;
        font-size: 15px;
        border-radius: 6px;
        border: 1px solid #cbd1d8;
        margin-bottom: 16px;
        transition: border .25s, box-shadow .25s;
    }

    input:focus {
        border-color: #007bff;
        box-shadow: 0 0 6px rgba(0,123,255,0.32);
        outline: none;
    }

    button {
        width: 100%;
        padding: 12px;
        font-size: 16px;
        font-weight: 600;
        background: #007bff;
        border: none;
        border-radius: 6px;
        color: #fff;
        cursor: pointer;
        margin-top: 5px;
        transition: background .25s;
    }

    button:hover {
        background: #005fcc;
    }

    .footer-text {
        font-size: 13px;
        color: #666;
        margin-top: 14px;
    }
    .home-btn {
    display: block;
    width: 93%;
    margin: 8px auto 0;
    padding: 10px;
    text-align: center;
    font-size: 15px;
    border: 1px solid #007bff;
    border-radius: 6px;
    text-decoration: none;
    color: #007bff;
    background: #fff;
    transition: 0.25s;
}

.home-btn:hover {
    background: #e9f3ff;
}

</style>
</head>

<body>
<div class="login-box">
    <h2>Đăng nhập hệ thống</h2>

    <form method="POST" action="xuly_login.php">
        <label>Số điện thoại:</label>
        <input type="text" name="so_dien_thoai" required>

        <label>Mật khẩu:</label>
        <input type="password" name="password" required>

        <button type="submit">Đăng nhập</button>
        <a href="index.html" class="home-btn">Về trang chủ</a>
    </form>

    <div class="footer-text">© 2025 Hệ thống quản lý CSVC</div>
</div>
</body>
</html>
