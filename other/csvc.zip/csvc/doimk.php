<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Đổi mật khẩu</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      padding: 40px;
    }

    form {
      background-color: #fff;
      padding: 25px;
      border-radius: 8px;
      max-width: 400px;
      margin: auto;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    label {
      font-weight: bold;
      display: block;
      margin-bottom: 5px;
    }

    input[type="password"] {
      width: calc(100% - 40px);
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    .password-wrapper {
      position: relative;
    }

    .toggle-password {
      position: absolute;
      right: 10px;
      top: 10px;
      cursor: pointer;
      background: none;
      border: none;
      font-size: 14px;
      color: #007bff;
    }

    input[type="submit"] {
      background-color: #007bff;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      width: 100%;
    }

    input[type="submit"]:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>

<form method="POST" action="change_password.php">
  <div class="password-wrapper">
    <label for="current_password">Mật khẩu hiện tại:</label>
    <input type="password" id="current_password" name="current_password" required>
    <button type="button" class="toggle-password" onclick="togglePassword('current_password')">👁️</button>
  </div>

  <div class="password-wrapper">
    <label for="new_password">Mật khẩu mới:</label>
    <input type="password" id="new_password" name="new_password" required>
    <button type="button" class="toggle-password" onclick="togglePassword('new_password')">👁️</button>
  </div>

  <div class="password-wrapper">
    <label for="confirm_password">Xác nhận mật khẩu mới:</label>
    <input type="password" id="confirm_password" name="confirm_password" required>
    <button type="button" class="toggle-password" onclick="togglePassword('confirm_password')">👁️</button>
  </div>

  <input type="submit" value="Đổi mật khẩu">
</form>

<script>
  function togglePassword(id) {
    const input = document.getElementById(id);
    input.type = input.type === "password" ? "text" : "password";
  }
</script>

</body>
</html>
