<!DOCTYPE html>
<html lang="vi">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Lịch sử bảo trì</title>
  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/tailwind.css">
</head>

<body>

  <nav>
    <a href="index.html">Trang chủ</a>
    <a href="thietbi.php">Thiết bị</a>
    <a href="phong.php">Phòng</a>
    <a href="nhanvien.php">Nhân viên</a>
    <a href="baotri.php">Bảo trì</a>
  </nav>

  <div class="p-1">
    <header class="flex justify-between">
      <h1 class="text-3xl font-semibold">Lịch sử bảo trì</h1>
    </header>
    <div class="my-container p-1 my-1" id="table-thietbi"></div>
  </div>

  <script src="assets/js/get_thietbi.js">
  </script>
</body>

</html>