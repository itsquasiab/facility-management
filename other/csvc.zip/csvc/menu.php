   <nav>
        <a href="index.html">Trang chủ</a>
        <a href="thietbi.php">Thiết bị</a>
        <a href="phong.php">Phòng</a>
        <a href="nhanvien.php">Nhân viên</a>
        <a href="baotri.php">Bảo trì</a>
        <?php
        session_start();
        if (!isset($_SESSION['quyen']) || !isset($_SESSION['ho_ten'])) {
        
        echo "<a href='login.php'>Đăng nhập</a>";
 
}else{
echo "<a href='logout.php'>Đăng xuất</a>
      <a href='doimk.php'>Đổi mật khẩu</a>";

}

        
        ?>
        
        
    
    </nav>